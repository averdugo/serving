

var demo_tasks = {
	"data":[
		{"id":11, "text":"ot", "name":"aa ", "group":"DT1 ", "start_date":"01-01-2016", "duration":"3", "open": true},
		{"id":1, "text":"Project #2", "name":"aa ","group":"aa ", "start_date":"02-01-2016", "duration":"2", "open": true},
		{"id":2, "text":"ot", "name":"aa ",  "start_date":"01-01-2016","group":"aa ", "duration":"3", "open": true},
		{"id":3, "text":"Project #2", "name":"aa ", "start_date":"02-01-2016","group":"aa ", "duration":"2", "open": true},
		{"id":4, "text":"ot", "name":"aa ",  "start_date":"01-01-2016", "duration":"3","group":"aa ", "open": true},
		{"id":5, "text":"Project #2", "name":"aa ", "start_date":"02-01-2016", "duration":"2", "group":"aa ","open": true},
		{"id":6, "text":"Project #2", "name":"aa ", "start_date":"02-01-2016", "duration":"2", "group":"aa ","open": true}

	]
};



